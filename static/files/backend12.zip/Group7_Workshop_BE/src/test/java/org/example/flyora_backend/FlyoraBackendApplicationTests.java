package org.example.flyora_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlyoraBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
