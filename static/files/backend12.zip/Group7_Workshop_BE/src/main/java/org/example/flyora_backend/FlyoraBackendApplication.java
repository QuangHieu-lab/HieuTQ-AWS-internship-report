package org.example.flyora_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlyoraBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(FlyoraBackendApplication.class, args);
    }
}

