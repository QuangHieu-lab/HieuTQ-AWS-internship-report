package org.example.flyora_backend.DTOs;

public class PayOSCallbackDTO {
    private String paymentCode;

    public String getPaymentCode() {
        return paymentCode;
    }

    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }
}